-- Table: Eval_Child
CREATE TABLE eval_child(
	evaluation_id INT NOT NULL,
	child_id INT NOT NULL,
	PRIMARY KEY (evaluation_id)
	);