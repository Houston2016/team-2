-- Table: Activity
CREATE TABLE activity(
	activity_id INT NOT NULL AUTO_INCREMENT,
	activity_name VARCHAR(30) NOT NULL,
	activity_path VARCHAR(50),
	PRIMARY KEY (activity_id)
	);