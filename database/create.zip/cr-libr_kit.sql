-- Table: Libr_Kit
CREATE TABLE libr_kit(
	library_id INT NOT NULL,
	kit_id INT NOT NULL,
	PRIMARY KEY (library_id)
	);